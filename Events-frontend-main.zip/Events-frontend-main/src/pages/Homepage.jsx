import React from "react";
import { Link } from "react-router-dom";

// --- Icons (SVGs) ---
const CalendarIcon = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
    stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect width="18" height="18" x="3" y="4" rx="2" ry="2" />
    <line x1="16" y1="2" x2="16" y2="6" />
    <line x1="8" y1="2" x2="8" y2="6" />
    <line x1="3" y1="10" x2="21" y2="10" />
  </svg>
);

const UsersIcon = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
    stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
    <circle cx="9" cy="7" r="4" />
    <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
    <path d="M16 3.13a4 4 0 0 1 0 7.75" />
  </svg>
);

// --- Component ---
const HomePage = ({ isAuthenticated, onTestApi }) => {
  return (
    <div className="flex flex-col items-center justify-center min-h-[90vh] p-4 text-center">
      <div className="max-w-4xl w-full bg-white shadow-2xl rounded-3xl p-8 sm:p-12 transition-all duration-300 hover:shadow-3xl">
        
        {/* Header */}
        <h1 className="text-5xl font-extrabold text-indigo-700 mb-4 sm:text-6xl tracking-tight">
          E&C Connect
        </h1>
        <p className="text-xl text-gray-600 mb-10 font-medium">
          Your centralized hub for Events and Community Clubs. Discover, join, and organize.
        </p>

        {/* Cards (auth box removed) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
          
          {/* Events Card */}
          <div className="p-6 bg-indigo-50 border border-indigo-200 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300">
            <CalendarIcon className="w-8 h-8 text-indigo-500 mb-3 mx-auto" />
            <h3 className="text-xl font-bold text-gray-800 mb-2">Find Events around you</h3>
            <p className="text-sm text-gray-600 mb-4">
              Browse professional gatherings, workshops, and social meetups.
            </p>
            <Link
              to="find-events"
              className="inline-block w-full bg-indigo-500 hover:bg-indigo-600 text-white font-semibold py-2 rounded-lg shadow transition-colors"
            >
              Explore Now
            </Link>
          </div>

          {/* Clubs Card */}
          <div className="p-6 bg-green-50 border border-green-200 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300">
            <UsersIcon className="w-8 h-8 text-green-500 mb-3 mx-auto" />
            <h3 className="text-xl font-bold text-gray-800 mb-2">Join Clubs</h3>
            <p className="text-sm text-gray-600 mb-4">
              Find communities centered around your hobbies and interests.
            </p>
            <Link
              to="/clubs"
              className="inline-block w-full bg-green-500 hover:bg-green-600 text-white font-semibold py-2 rounded-lg shadow transition-colors"
            >
              Discover Clubs
            </Link>
          </div>

        </div>

        {/* API Button */}
        <button
          onClick={onTestApi}
          className="mt-6 text-sm text-indigo-500 hover:text-indigo-700 transition-colors font-medium border-b border-dashed border-indigo-300"
        >
          Click to Test API Connection (`/api/auth/register`)
        </button>
      </div>
    </div>
  );
};

export default HomePage;
