import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";

// safe env read — avoids "process is not defined" in some browser setups
const API_BASE = (() => {
  if (typeof process !== "undefined" && process.env && process.env.REACT_APP_API_URL) {
    return process.env.REACT_APP_API_URL;
  }
  if (typeof window !== "undefined" && window.REACT_APP_API_URL) {
    return window.REACT_APP_API_URL;
  }
  return "http://localhost:8000";
})();

export default function IndividualEvent() {
  const { id } = useParams();
  const [event, setEvent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!id) return;
    const fetchEvent = async () => {
      try {
        setLoading(true);
        const res = await fetch(`${API_BASE}/api/events/${id}`);
        if (!res.ok) throw new Error("Failed to fetch event");
        const data = await res.json();
        setEvent(data);
        setError(null);
      } catch (err) {
        setError(err.message || "Error");
      } finally {
        setLoading(false);
      }
    };
    fetchEvent();
  }, [id]);

  const formatDate = (date) => {
    if (!date) return "TBD";
    return new Date(date).toLocaleDateString("en-US", {
      weekday: "short",
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const getImageUrl = (img) => {
    const fallback = "/placeholder-event.jpg";
    if (!img) return fallback;
    if (typeof img !== "string") return fallback;
    if (img.startsWith("http")) return img;
    return img.startsWith("/") ? `${API_BASE}${img}` : `${API_BASE}/${img}`;
  };

  // show price in Indian rupees (stored in smallest unit, e.g. paise)
  const formatPrice = (pricePaise) => {
    if (!pricePaise && pricePaise !== 0) return "Free";
    return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(pricePaise / 100);
  };

  if (loading) return <div className="py-20 text-center">Loading...</div>;
  if (error) return <div className="py-20 text-center text-red-500">Error: {error}</div>;
  if (!event) return <div className="py-20 text-center">Event not found</div>;

  return (
    <div className="px-5 md:px-10 lg:px-20 py-10 max-w-[900px] mx-auto">
      <Link to="/find-events" className="text-sm text-purple-600 hover:underline">← Back to events</Link>

      <div className="bg-white rounded-xl shadow-lg overflow-hidden mt-4">
        <img
          src={getImageUrl(event.image)}
          alt={event.title || "Event image"}
          className="w-full h-96 object-cover"
        />
        <div className="p-6">
          <div className="flex items-start justify-between">
            <h1 className="text-3xl font-bold mb-3 text-purple-700">{event.title}</h1>
            <div className="text-right">
              <div className="text-sm text-gray-500">Price</div>
              <div className="text-lg font-semibold text-purple-600">{formatPrice(event.price)}</div>
            </div>
          </div>

          <p className="text-gray-500 mb-2">📅 {formatDate(event.date)}</p>

          <p className="text-gray-500 mb-2">
            📍{" "}
            {event.isOnline
              ? "Online"
              : event.location?.venue
              ? `${event.location.venue}${event.location.city ? `, ${event.location.city}` : ""}`
              : "TBA"}
          </p>

          <p className="text-gray-500 mb-4">
            👥 {Array.isArray(event.attendees) ? event.attendees.length : (event.attendees ?? 0)}
            {event.maxAttendees ? ` / ${event.maxAttendees}` : ""} attendees
          </p>

          <div className="flex gap-3 items-center mb-4">
            <Link
              to={`/events/${id}/join`}
              className="px-4 py-2 border border-purple-600 text-purple-600 rounded-lg hover:bg-purple-50 inline-flex items-center justify-center"
            >
              Join with details & payment
            </Link>
          </div>

          {event.description && (
            <>
              <h3 className="text-lg font-semibold mb-2">Description</h3>
              <p className="text-gray-700 whitespace-pre-line">{event.description}</p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}