import React, { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";

// safe env read for client
const API_BASE =
  (typeof process !== "undefined" && process.env && process.env.REACT_APP_API_URL) ||
  (typeof window !== "undefined" && window.REACT_APP_API_URL) ||
  "http://localhost:8000";

function FindEventsPage() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");

  // ref for debounce timer
  const searchDebounceRef = useRef(null);

  // fetch events accepts optional query string to avoid closure issues
  const fetchEvents = async (q = "") => {
    try {
      setLoading(true);
      const queryParams = new URLSearchParams();
      if (q) queryParams.append("search", q);
      const res = await fetch(`${API_BASE}/api/events?${queryParams}`);
      if (!res.ok) throw new Error("Failed to fetch events");
      const data = await res.json();
      setEvents(data);
      setError(null);
    } catch (err) {
      setError(err.message || "Error fetching events");
    } finally {
      setLoading(false);
    }
  };

  // initial load
  useEffect(() => {
    fetchEvents();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // debounce searchTerm changes so typing won't trigger a fetch on every keystroke
  useEffect(() => {
    // clear previous timer
    if (searchDebounceRef.current) clearTimeout(searchDebounceRef.current);

    // if empty search, fetch immediately (or you can debounce here too)
    const delay = searchTerm ? 400 : 0;

    searchDebounceRef.current = setTimeout(() => {
      fetchEvents(searchTerm.trim());
    }, delay);

    return () => {
      if (searchDebounceRef.current) clearTimeout(searchDebounceRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchTerm]);

  const formatDate = (date) => {
    if (!date) return "TBD";
    return new Date(date).toLocaleDateString("en-US", {
      weekday: "short",
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const getImageUrl = (img) => {
    const fallback = "/placeholder-event.jpg";
    if (!img) return fallback;
    if (typeof img !== "string") return fallback;
    if (img.startsWith("http")) return img;
    return img.startsWith("/") ? `${API_BASE}${img}` : `${API_BASE}/${img}`;
  };

  if (loading)
    return (
      <div className="py-20 text-center">
        <h2 className="text-2xl font-semibold text-purple-600">Loading events...</h2>
      </div>
    );

  if (error)
    return (
      <div className="py-20 text-center text-red-500">
        <h2 className="text-2xl font-semibold mb-4">Error: {error}</h2>
        <button onClick={() => fetchEvents(searchTerm)} className="px-6 py-2 bg-red-500 text-white rounded-lg">
          Retry
        </button>
      </div>
    );

  return (
    <div className="px-5 md:px-10 lg:px-20 py-10 max-w-[1400px] mx-auto">
      <h1 className="text-4xl md:text-5xl font-extrabold text-center mb-12 text-purple-700">
        Find Events
      </h1>

      {/* Filters - only search */}
      <div className="flex flex-wrap justify-center gap-4 mb-10">
        <input
          type="text"
          placeholder="Search events..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="px-4 py-2 rounded-lg border border-purple-200 focus:outline-none focus:ring-2 focus:ring-purple-300 w-full md:w-96"
        />
      </div>

      {/* Event Cards */}
      {events.length === 0 ? (
        <p className="text-center text-gray-500 text-lg">No events found. Try adjusting your search.</p>
      ) : (
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {events.map((event) => {
            const id = event._id || event.id;
            return (
              <Link key={id || Math.random()} to={`/events/${id}`} className="block">
                <div className="rounded-xl overflow-hidden transform transition hover:scale-105 cursor-pointer border border-purple-50 bg-white shadow-sm min-h-[32rem] flex flex-col">
                  <img
                    src={getImageUrl(event.image)}
                    alt={event.title || "Event image"}
                    className="w-full h-80 object-cover transition-shadow duration-150 hover:shadow-lg"
                  />
                  <div className="p-5 flex flex-col flex-grow">
                    <h3 className="text-2xl font-semibold mb-2 text-gray-800 text-purple-700 h-16 overflow-hidden line-clamp-2">
                      {event.title}
                    </h3>

                    <p className="text-gray-500 text-sm mb-2">📅 {formatDate(event.date)}</p>

                    <p className="text-gray-500 text-sm mb-2">
                      📍{" "}
                      {event.isOnline
                        ? "Online"
                        : event.location?.venue
                        ? `${event.location.venue}${event.location.city ? `, ${event.location.city}` : ""}`
                        : "TBA"}
                    </p>

                    <p className="text-gray-500 text-sm mt-auto">
                      👥 {Array.isArray(event.attendees) ? event.attendees.length : event.attendees ?? 0}
                      {event.maxAttendees ? ` / ${event.maxAttendees}` : ""} attendees
                    </p>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}

export default FindEventsPage;
