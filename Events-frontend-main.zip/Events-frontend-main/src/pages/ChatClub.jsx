import React, { useEffect, useState, useRef, useCallback } from "react";
import { useParams, Link } from "react-router-dom";

const API_BASE =
  (typeof process !== "undefined" && process.env && process.env.REACT_APP_API_URL) ||
  (typeof window !== "undefined" && window.REACT_APP_API_URL) ||
  "http://localhost:8000";

export default function ChatClub() {
  const { id: clubId } = useParams();
  const [club, setClub] = useState(null);
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState("");
  const [file, setFile] = useState(null);
  const [filePreview, setFilePreview] = useState(null);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [typingUsers, setTypingUsers] = useState({});
  const socketRef = useRef(null);
  const scrollRef = useRef(null);
  const inputRef = useRef(null);
  const typingTimeout = useRef(null);

  const fetchClubAndMessages = useCallback(async () => {
    setLoading(true);
    try {
      const [clubRes, msgsRes] = await Promise.all([
        fetch(`${API_BASE}/api/clubs/${clubId}`),
        fetch(`${API_BASE}/api/clubs/${clubId}/messages`),
      ]);
      if (clubRes.ok) setClub(await clubRes.json());
      if (msgsRes.ok) {
        const data = await msgsRes.json();
        data.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
        setMessages(data);
        setTimeout(scrollToBottom, 120);
      }
    } catch (err) {
      console.error("Failed to load chat:", err);
    } finally {
      setLoading(false);
    }
  }, [clubId]);

  useEffect(() => {
    fetchClubAndMessages();

    let mounted = true;
    (async () => {
      try {
        const mod = await import("socket.io-client");
        const factory = mod.io || mod.default || mod;
        const socket = factory(API_BASE, { transports: ["websocket"], reconnectionAttempts: 5 });
        if (!mounted) return;
        socketRef.current = socket;

        socket.on("connect", () => socket.emit("club:join", { clubId }));
        socket.on("club:message", (msg) => {
          setMessages((prev) => {
            if (msg._tempId) {
              return prev.map((m) => (m._tempId === msg._tempId ? msg : m));
            }
            if (prev.some((m) => m._id === msg._id)) return prev;
            return [...prev, msg];
          });
          scrollToBottom();
        });
        socket.on("club:typing", ({ userId, name, typing }) => {
          setTypingUsers((t) => ({ ...t, [userId]: typing ? name : undefined }));
        });
      } catch (e) {}
    })();

    return () => {
      mounted = false;
      if (socketRef.current) {
        socketRef.current.emit("club:leave", { clubId });
        socketRef.current.disconnect();
        socketRef.current = null;
      }
      if (filePreview) URL.revokeObjectURL(filePreview);
    };
  }, [clubId, fetchClubAndMessages, filePreview]);

  function scrollToBottom() {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }

  const emitTyping = (isTyping = true) => {
    const socket = socketRef.current;
    if (!socket) return;
    socket.emit("club:typing", { clubId, typing: isTyping });
    if (typingTimeout.current) clearTimeout(typingTimeout.current);
    if (isTyping) {
      typingTimeout.current = setTimeout(() => emitTyping(false), 1500);
    }
  };

  function handleFileChange(e) {
    const f = e.target.files?.[0] || null;
    if (filePreview) {
      URL.revokeObjectURL(filePreview);
    }
    setFile(f);
    setFilePreview(f ? URL.createObjectURL(f) : null);
  }

  async function handleSend(e) {
    e?.preventDefault();
    if (!text.trim() && !file) return;

    const tempId = `temp-${Date.now()}`;
    const optimistic = {
      _tempId: tempId,
      text: text.trim() || undefined,
      image: file ? URL.createObjectURL(file) : undefined,
      sender: { name: "You" },
      createdAt: new Date().toISOString(),
      pending: true,
    };
    setMessages((m) => [...m, optimistic]);
    setText("");
    setFile(null);
    scrollToBottom();
    inputRef.current?.focus();

    const socket = socketRef.current;
    if (socket && socket.connected) {
      try {
        socket.emit("club:message", { clubId, text: optimistic.text, _tempId: tempId }, (ack) => {
          if (ack && ack._id) {
            setMessages((prev) => prev.map((msg) => (msg._tempId === tempId ? ack : msg)));
            scrollToBottom();
          }
        });
        return;
      } catch (err) {}
    }

    setSending(true);
    try {
      const form = new FormData();
      if (optimistic.text) form.append("text", optimistic.text);
      if (file) form.append("image", file);

      const res = await fetch(`${API_BASE}/api/clubs/${clubId}/messages`, {
        method: "POST",
        body: form,
      });
      const saved = await res.json();
      setMessages((prev) => prev.map((m) => (m._tempId === tempId ? saved : m)));
      scrollToBottom();
    } catch (err) {
      console.error("Send failed:", err);
    } finally {
      setSending(false);
    }
  }

  if (loading) {
    return (
      <div className="h-screen flex items-center justify-center text-purple-600 text-2xl font-semibold">
        Loading chat…
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col bg-gradient-to-b from-gray-100 to-white">
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-3 bg-white/80 backdrop-blur border-b shadow-sm">
        <div className="flex items-center gap-3">
          <Link to="/clubs" className="text-sm text-purple-600 hover:underline">← Back</Link>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center text-purple-700 font-semibold">
              {club?.name?.[0] ?? "C"}
            </div>
            <div>
              <div className="text-lg font-semibold text-gray-800">{club?.name || "Club Chat"}</div>
              <div className="text-xs text-gray-500">{club?.members?.length ?? 0} members</div>
            </div>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-auto p-6 space-y-4 bg-[#F5F7FB]">
        {messages.map((m) => {
          const mine = m.sender?.name === "You" || m.me || m.isMine;
          return (
            <div key={m._id || m._tempId} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-[70%] px-4 py-2 rounded-2xl ${
                  mine
                    ? "bg-purple-600 text-white rounded-br-none"
                    : "bg-white text-gray-800 rounded-bl-none shadow"
                }`}
              >
                {!mine && <div className="text-xs text-gray-500 font-medium mb-1">{m.sender?.name ?? "Member"}</div>}
                {m.text && <div className="whitespace-pre-wrap break-words">{m.text}</div>}
                {m.image && (
                  <img
                    src={m.image.startsWith("http") ? m.image : `${API_BASE}${m.image}`}
                    alt="attachment"
                    className="mt-2 rounded-lg max-h-64 object-cover w-full"
                  />
                )}
                <div className="mt-1 text-[10px] opacity-70 flex justify-end">
                  {new Date(m.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Composer */}
      <form
        onSubmit={handleSend}
        className="flex items-center gap-3 p-4 bg-white/80 backdrop-blur border-t shadow-inner"
      >
        <label className="cursor-pointer p-2 rounded-full hover:bg-gray-100">
          <input type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
          <svg
            className="w-6 h-6 text-gray-500"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="M15.172 7l-6.414 6.414A4 4 0 1014 17l6.414-6.414a2 2 0 10-2.828-2.828L11.172 14.172" />
          </svg>
        </label>

        <input
          ref={inputRef}
          value={text}
          onChange={(e) => {
            setText(e.target.value);
            emitTyping(true);
          }}
          placeholder="Type a message…"
          className="flex-1 px-4 py-2 border rounded-full focus:outline-none focus:ring-2 focus:ring-purple-300 text-gray-800 bg-white"
        />

        <button
          type="submit"
          disabled={sending}
          className="px-5 py-2 bg-purple-600 text-white rounded-full hover:bg-purple-700 transition disabled:opacity-60"
        >
          {sending ? "…" : "Send"}
        </button>
      </form>
    </div>
  );
}
