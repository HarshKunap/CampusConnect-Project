import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";

// safe env read for client
const API_BASE =
  (typeof process !== "undefined" && process.env && process.env.REACT_APP_API_URL) ||
  (typeof window !== "undefined" && window.REACT_APP_API_URL) ||
  "http://localhost:8000";

export default function FindClubs() {
  const [clubs, setClubs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [joinLoadingId, setJoinLoadingId] = useState(null);
  const [joinedIds, setJoinedIds] = useState(new Set());

  useEffect(() => {
    fetchClubs();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchTerm]);

  const fetchClubs = async () => {
    try {
      setLoading(true);
      const queryParams = new URLSearchParams();
      if (searchTerm) queryParams.append("search", searchTerm);

      const res = await fetch(`${API_BASE}/api/clubs?${queryParams}`);
      if (!res.ok) throw new Error("Failed to fetch clubs");
      const data = await res.json();
      setClubs(Array.isArray(data) ? data : []);
      setError(null);
    } catch (err) {
      setError(err.message || "Error fetching clubs");
    } finally {
      setLoading(false);
    }
  };

  // helper to build image url
  const getImageUrl = (img) => {
    const fallback = "/placeholder-event.jpg";
    if (!img) return fallback;
    if (typeof img !== "string") return fallback;
    if (img.startsWith("http")) return img;
    return img.startsWith("/") ? `${API_BASE}${img}` : `${API_BASE}/${img}`;
  };

  // join club handler (simple POST, adjust endpoint/auth as needed)
  async function handleJoin(clubId) {
    if (!clubId || joinedIds.has(clubId)) return;
    setJoinLoadingId(clubId);
    try {
      const res = await fetch(`${API_BASE}/api/clubs/${clubId}/join`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}), // add auth or payload if backend requires
      });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body.message || "Failed to join club");
      }
      // mark as joined locally
      setJoinedIds((s) => {
        const next = new Set(s);
        next.add(clubId);
        return next;
      });
    } catch (err) {
      console.error("Join failed:", err);
      // optionally show toast / error UI
      alert(err.message || "Could not join club");
    } finally {
      setJoinLoadingId(null);
    }
  }

  if (loading)
    return (
      <div className="py-20 text-center">
        <h2 className="text-2xl font-semibold text-purple-600">Loading clubs...</h2>
      </div>
    );

  if (error)
    return (
      <div className="py-20 text-center text-red-500">
        <h2 className="text-2xl font-semibold mb-4">Error: {error}</h2>
        <button onClick={fetchClubs} className="px-6 py-2 bg-red-500 text-white rounded-lg">
          Retry
        </button>
      </div>
    );

  return (
    <div className="px-5 md:px-10 lg:px-20 py-10 max-w-[1400px] mx-auto">
      <h1 className="text-4xl md:text-5xl font-extrabold text-center mb-12 text-purple-700">
        Find Clubs
      </h1>

      {/* Only search bar (categories/time filters removed) */}
      <div className="flex flex-wrap justify-center gap-4 mb-10">
        <input
          type="text"
          placeholder="Search clubs..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="px-4 py-2 rounded-lg border border-purple-200 focus:outline-none focus:ring-2 focus:ring-purple-300 w-full md:w-96"
        />
      </div>

      {/* Club Cards */}
      {clubs.length === 0 ? (
        <p className="text-center text-gray-500 text-lg">No clubs found. Try adjusting your search.</p>
      ) : (
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {clubs.map((club) => {
            const id = club._id || club.id;
            const isJoined = joinedIds.has(id);
            return (
              <div key={id || Math.random()} className="block">
                <div className="rounded-xl overflow-hidden transform transition hover:scale-105 cursor-default border border-purple-50 bg-white shadow-sm">
                  <Link to={`/clubs/${id}/chat`} className="block">
                    <img
                      src={getImageUrl(club.image)}
                      alt={club.name || "Club image"}
                      className="w-full h-80 object-cover transition-shadow duration-150 hover:shadow-lg"
                    />
                  </Link>

                  <div className="p-5">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <h3 className="text-2xl font-semibold mb-2 text-purple-700">{club.name}</h3>
                        <p className="text-gray-500 text-sm mb-2">
                          {club.location?.city ? `📍 ${club.location.city}` : club.isOnline ? "🌐 Online" : "📍 TBA"}
                        </p>
                        {/* show only number of members */}
                        <p className="text-gray-500 text-sm">
                          👥 {Array.isArray(club.members) ? club.members.length : club.membersCount ?? 0} members
                        </p>
                      </div>

                      <div className="flex flex-col items-end gap-2">
                        {/* View button removed — only Join remains */}
                        
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}