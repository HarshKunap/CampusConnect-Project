import React from "react";
import { Link } from "react-router-dom";

export default function Privacy() {
  const lastUpdated = new Date().toLocaleDateString();

  return (
    <div className="min-h-screen bg-white text-gray-800">
      {/* Header */}
      <header className="border-b border-gray-200 py-12 px-6 md:px-20">
        <h1 className="text-4xl font-bold text-gray-900 mb-2">Privacy Policy</h1>
        <p className="text-sm text-gray-500">Last updated: {lastUpdated}</p>
      </header>

      {/* Main Content */}
      <main className="px-6 md:px-20 py-12 space-y-12 leading-relaxed">
        <section>
          <p className="text-lg">
            At <span className="font-semibold">E&C Connect</span>, we respect your privacy and are committed to
            protecting your personal information. This Privacy Policy explains how we collect, use, and safeguard your
            data when you use our platform to explore clubs, register for events, and connect with your community.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="text-2xl font-semibold text-gray-900">1. Information We Collect</h2>
          <ul className="list-disc ml-6 space-y-2">
            <li>
              <span className="font-medium">Personal Details:</span> Information such as your name, email, phone number,
              and college when you create an account or join clubs.
            </li>
            <li>
              <span className="font-medium">Uploads:</span> Files like payment receipts or event registration documents.
            </li>
            <li>
              <span className="font-medium">Usage Data:</span> Pages visited, actions taken, IP address, browser type,
              and device information to improve our service.
            </li>
            <li>
              <span className="font-medium">Cookies:</span> Small data files that enhance site functionality and remember
              your preferences.
            </li>
          </ul>
        </section>

        <section className="space-y-3">
          <h2 className="text-2xl font-semibold text-gray-900">2. How We Use Your Information</h2>
          <ul className="list-disc ml-6 space-y-2">
            <li>To manage club memberships and event registrations.</li>
            <li>To send confirmations, updates, and relevant communications.</li>
            <li>To improve platform usability, design, and functionality.</li>
            <li>To ensure compliance and prevent misuse or fraudulent activity.</li>
          </ul>
        </section>

        <section className="space-y-3">
          <h2 className="text-2xl font-semibold text-gray-900">3. Sharing & Disclosure</h2>
          <p>
            We do not sell or rent your personal data. We may share limited information only in the following cases:
          </p>
          <ul className="list-disc ml-6 space-y-2">
            <li>With trusted service providers (e.g., payment or analytics tools).</li>
            <li>When required by law or legitimate legal processes.</li>
            <li>With partner clubs or organizers, but only with your consent.</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-gray-900 mb-3">4. Data Retention & Your Rights</h2>
          <p>
            We retain your data only as long as needed for the purposes stated. You have the right to access, correct, or
            request deletion of your personal information by contacting our support team.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-gray-900 mb-3">5. Security Measures</h2>
          <p>
            We use encryption, secure servers, and access controls to protect your information. However, no system is
            completely secure — please notify us immediately if you suspect any unauthorized activity.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-gray-900 mb-3">6. Your Privacy Rights</h2>
          <ul className="list-disc ml-6 space-y-2">
            <li>Request access to the data we hold about you.</li>
            <li>Request correction of inaccurate or outdated information.</li>
            <li>Request deletion of your personal data.</li>
            <li>Withdraw consent to processing at any time.</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-gray-900 mb-3">7. Third-Party Services</h2>
          <p>
            We may link to or integrate with external services like analytics or payments. These third parties maintain
            their own privacy practices — please review their policies before using them.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-gray-900 mb-3">8. Policy Updates</h2>
          <p>
            We may update this Privacy Policy periodically. Any significant changes will be announced on our website or
            through email. The date at the top reflects the latest update.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-gray-900 mb-3">9. Contact Us</h2>
          <p>
            If you have questions, requests, or concerns about this Privacy Policy, please contact us at:
          </p>
          <p className="mt-2">
            📧{" "}
            <a
              href="mailto:support@ecconnect.example"
              className="text-blue-600 hover:underline"
            >
              support@ecconnect.example
            </a>
          </p>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-gray-200 text-gray-600 text-sm py-6 px-6 md:px-20 flex justify-between flex-wrap gap-2">
        <Link to="/" className="hover:text-blue-600 hover:underline">
          ← Back to Home
        </Link>
        <span>© {new Date().getFullYear()} E&C Connect. All rights reserved.</span>
      </footer>
    </div>
  );
}
