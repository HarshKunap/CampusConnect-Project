import React, { useEffect, useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { loadStripe } from "@stripe/stripe-js";

// Safe env read for client
const STRIPE_PK =
  (typeof process !== "undefined" && process.env && process.env.REACT_APP_STRIPE_PK) ||
  (typeof window !== "undefined" && window.REACT_APP_STRIPE_PK) ||
  "";
const stripePromise = STRIPE_PK ? loadStripe(STRIPE_PK) : null;

const API_BASE =
  (typeof process !== "undefined" && process.env && process.env.REACT_APP_API_URL) ||
  (typeof window !== "undefined" && window.REACT_APP_API_URL) ||
  "http://localhost:8000";

export default function JoinEvent() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [event, setEvent] = useState(null);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [mobile, setMobile] = useState("");
  const [age, setAge] = useState("");
  const [screenshot, setScreenshot] = useState(null);
  const [screenshotPreview, setScreenshotPreview] = useState(null);
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState(null);
  const [error, setError] = useState(null);
  const [submitted, setSubmitted] = useState(false);
  const [isEditing, setIsEditing] = useState(false);

  // cleanup preview URL on change/unmount
  useEffect(() => {
    return () => {
      if (screenshotPreview) URL.revokeObjectURL(screenshotPreview);
    };
  }, [screenshotPreview]);

  useEffect(() => {
    if (!id) return;
    const fetchEvent = async () => {
      try {
        const res = await fetch(`${API_BASE}/api/events/${id}`);
        if (!res.ok) throw new Error("Failed to load event");
        const data = await res.json();
        setEvent(data);
      } catch (err) {
        setError(err.message || "Error loading event");
      }
    };
    fetchEvent();
  }, [id]);

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setMsg(null);

    const isPaymentExpected = event?.price > 0 || event?.qrPaymentImage;
    if (isPaymentExpected && !screenshot) {
      setError("Payment is required. Please upload a screenshot of your payment.");
      setLoading(false);
      return;
    }

    try {
      const formData = new FormData();
      formData.append("name", name);
      formData.append("email", email);
      formData.append("mobile", mobile);
      formData.append("age", age);
      if (screenshot) formData.append("screenshot", screenshot);

      const res = await fetch(`${API_BASE}/api/events/${id}/join`, {
        method: "POST",
        body: formData,
      });

      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body.message || "Failed to register");
      }

      // ✅ Success message and switch to view mode
      setMsg("Registration uploaded successfully! You will receive a confirmation message soon.");
      setSubmitted(true);
      setIsEditing(false);
    } catch (err) {
      setError(err.message || "Error registering");
    } finally {
      setLoading(false);
    }
  };

  const handlePayment = async () => {
    if (!stripePromise) {
      setError("Stripe public key not configured. Set REACT_APP_STRIPE_PK.");
      return;
    }
    setLoading(true);
    setError(null);

    try {
      const res = await fetch(`${API_BASE}/api/create-checkout-session`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ eventId: id }),
      });

      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body.message || "Failed to create checkout session");
      }

      const { sessionId } = await res.json();
      const stripe = await stripePromise;
      await stripe.redirectToCheckout({ sessionId });
    } catch (err) {
      setError(err.message || "Payment error");
      setLoading(false);
    }
  };

  if (!event && !error) return <div className="py-20 text-center">Loading event...</div>;
  if (error)
    return (
      <div className="px-5 py-10 max-w-[800px] mx-auto text-center">
        <p className="text-red-600 mb-4">{error}</p>
        <Link to={`/events/${id}`} className="text-sm text-purple-600 hover:underline">
          Back to event
        </Link>
      </div>
    );

  const priceDisplay = event?.price
    ? new Intl.NumberFormat("en-IN", {
        style: "currency",
        currency: "INR",
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      }).format(event.price / 100)
    : "Free";

  const isPaymentExpected = event?.price > 0 || event?.qrPaymentImage;

  return (
    <div className="px-5 md:px-10 lg:px-20 py-10 max-w-[900px] mx-auto">
      <Link to={`/events/${id}`} className="text-sm text-purple-600 hover:underline">
        ← Back to event
      </Link>

      <div className="mt-6 bg-white rounded-xl shadow-md p-6">
        <h2 className="text-2xl font-semibold text-purple-700 mb-2">{event.title}</h2>
        <p className="text-sm text-gray-500 mb-4">
          📅 {new Date(event.date).toLocaleString()} • 📍{" "}
          {event.isOnline ? "Online" : event.location?.venue ?? "TBA"}
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-1">Attendees</h3>
            <p className="text-sm text-gray-600">
              {Array.isArray(event.attendees)
                ? event.attendees.length
                : event.attendees ?? 0}{" "}
              attending
            </p>

            <h3 className="text-sm font-medium text-gray-700 mt-4 mb-1">Capacity</h3>
            <p className="text-sm text-gray-600">
              {event.maxAttendees ? event.maxAttendees : "No limit"}
            </p>
          </div>

          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-1">Price</h3>
            <p className="text-sm text-gray-600">{priceDisplay}</p>

            <h3 className="text-sm font-medium text-gray-700 mt-4 mb-1">Host</h3>
            <p className="text-sm text-gray-600">{event.host?.name ?? "Organizer"}</p>
          </div>
        </div>

        {event.description && (
          <>
            <h3 className="text-sm font-medium text-gray-700 mb-1">About</h3>
            <p className="text-sm text-gray-600 whitespace-pre-line mb-4">
              {event.description}
            </p>
          </>
        )}

        {event.qrPaymentImage && (
          <div className="mb-6 border p-4 rounded-lg bg-gray-50 flex flex-col items-center text-center">
            <h3 className="text-lg font-bold text-gray-800 mb-3">
              Scan to Pay ({priceDisplay})
            </h3>
            <p className="text-sm text-gray-600 mb-3 max-w-sm">
              Please scan the QR code below to make your payment, then fill out the form and upload a screenshot of the successful transaction.
            </p>
            <img
              src={event.qrPaymentImage}
              alt="QR Payment Code"
              className="max-w-[200px] h-auto rounded-md shadow-lg border border-gray-200"
            />
          </div>
        )}

        {/* ✅ Toggle between FORM and READ-ONLY view */}
        {!submitted || isEditing ? (
          <form onSubmit={submit} className="space-y-4 mb-4" encType="multipart/form-data">
            <input
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-300 outline-none"
              placeholder="Your name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
            <input
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-300 outline-none"
              placeholder="Your email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <input
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-300 outline-none"
              placeholder="Your mobile number"
              type="tel"
              pattern="[0-9]{10}"
              title="Enter a valid 10-digit mobile number"
              value={mobile}
              onChange={(e) => setMobile(e.target.value)}
              required
            />
            <input
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-300 outline-none"
              placeholder="Your age"
              type="number"
              value={age}
              onChange={(e) => setAge(e.target.value)}
              required
            />

            {isPaymentExpected && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Upload Screenshot of Payment (Required)
                </label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => {
                    const f = e.target.files?.[0] || null;
                    if (screenshotPreview) URL.revokeObjectURL(screenshotPreview);
                    setScreenshot(f);
                    setScreenshotPreview(f ? URL.createObjectURL(f) : null);
                  }}
                  className="block w-full text-sm text-gray-600 border border-gray-300 rounded-lg cursor-pointer focus:outline-none"
                  required={isPaymentExpected}
                />
                {screenshotPreview && (
                  <div className="mt-3">
                    <p className="text-sm text-gray-600 mb-2">Payment screenshot preview:</p>
                    <img
                      src={screenshotPreview}
                      alt="Payment screenshot preview"
                      className="max-w-sm w-full object-contain rounded-md border"
                    />
                  </div>
                )}
              </div>
            )}

            <div className="flex gap-3 items-center">
              <button
                type="submit"
                disabled={loading}
                className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-60"
              >
                {loading ? "Saving…" : "Save Registration"}
              </button>
              {submitted && (
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-4 py-2 bg-gray-300 text-gray-800 rounded-lg hover:bg-gray-400"
                >
                  Cancel
                </button>
              )}
            </div>

            {msg && <p className="text-sm text-green-600 mt-2">{msg}</p>}
            {error && <p className="text-sm text-red-600 mt-2">{error}</p>}
          </form>
        ) : (
          <div className="space-y-3 border rounded-lg p-4 bg-gray-50 mb-4">
            <h3 className="text-lg font-semibold text-gray-800 mb-2">Your Information</h3>
            <p><strong>Name:</strong> {name}</p>
            <p><strong>Email:</strong> {email}</p>
            <p><strong>Mobile:</strong> {mobile}</p>
            <p><strong>Age:</strong> {age}</p>
            {screenshotPreview && (
              <div>
                <p className="font-medium text-gray-700 mb-1">Uploaded Payment Screenshot:</p>
                <img
                  src={screenshotPreview}
                  alt="Payment screenshot"
                  className="max-w-sm w-full object-contain rounded-md border"
                />
              </div>
            )}

            {/* ✅ Confirmation text after successful submission */}
            <p className="text-green-700 text-sm mt-3">
              ✅ You will receive a confirmation message soon. You can edit your details if you want.
            </p>

            <button
              onClick={() => setIsEditing(true)}
              className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700"
            >
              Edit Info
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
