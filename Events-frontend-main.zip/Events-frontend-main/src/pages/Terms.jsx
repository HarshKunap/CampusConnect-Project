import React from "react";
import { Link } from "react-router-dom";

export default function Terms() {
  const lastUpdated = new Date().toLocaleDateString();

  return (
    <div className="min-h-screen bg-white text-gray-800">
      {/* Header */}
      <header className="border-b border-gray-200 py-12 px-6 md:px-20">
        <h1 className="text-4xl font-bold text-gray-900 mb-2">Terms of Service</h1>
        <p className="text-sm text-gray-500">Last updated: {lastUpdated}</p>
      </header>

      {/* Main Content */}
      <main className="px-6 md:px-20 py-12 space-y-12 leading-relaxed">
        <section>
          <p className="text-lg">
            Welcome to <span className="font-semibold">E&C Connect</span>! These Terms of Service (“Terms”) govern your
            use of our website, mobile app, and all related services. By accessing or using our platform, you agree to
            comply with these Terms. Please read them carefully before proceeding.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-gray-900 mb-3">1. Acceptance of Terms</h2>
          <p>
            By creating an account or using any part of our service, you confirm that you are at least 13 years old and
            have the legal capacity to enter into this agreement. If you do not agree to these Terms, please stop using
            the platform immediately.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-gray-900 mb-3">2. Description of Service</h2>
          <p>
            E&C Connect provides a digital platform for students to discover, join, and manage clubs or events within
            their community. We aim to simplify event participation, promote collaboration, and help organizations
            connect with members effectively.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-gray-900 mb-3">3. User Responsibilities</h2>
          <ul className="list-disc ml-6 space-y-2">
            <li>You agree to provide accurate, complete, and updated information when registering or joining clubs.</li>
            <li>You are responsible for maintaining the confidentiality of your account credentials.</li>
            <li>
              You agree not to misuse the platform — including posting false information, spam, or engaging in
              disruptive or illegal activity.
            </li>
            <li>
              You must respect all applicable laws, event rules, and university/organization policies while using the
              service.
            </li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-gray-900 mb-3">4. Club and Event Content</h2>
          <p>
            Clubs, event organizers, and members are solely responsible for the content they create, upload, or share.
            E&C Connect does not endorse or verify all user-generated content. We reserve the right to remove material
            that violates our policies or community standards.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-gray-900 mb-3">5. Payments and Transactions</h2>
          <p>
            Certain events or clubs may require payments or registration fees. All transactions are handled securely via
            integrated third-party payment gateways. E&C Connect is not responsible for transaction issues caused by
            payment providers or incorrect user input.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-gray-900 mb-3">6. Intellectual Property</h2>
          <p>
            All content, branding, and design elements on E&C Connect (excluding user-generated materials) are protected
            by copyright and intellectual property laws. You may not copy, distribute, or modify our materials without
            written permission.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-gray-900 mb-3">7. Termination of Access</h2>
          <p>
            We reserve the right to suspend or terminate accounts that violate these Terms, misuse the service, or
            engage in harmful behavior. You may delete your account at any time by contacting our support team.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-gray-900 mb-3">8. Limitation of Liability</h2>
          <p>
            E&C Connect is provided “as is” and “as available.” We do not guarantee uninterrupted or error-free service.
            To the fullest extent permitted by law, E&C Connect is not liable for any indirect, incidental, or
            consequential damages resulting from your use of the platform.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-gray-900 mb-3">9. Privacy Policy</h2>
          <p>
            Your use of the platform is also governed by our{" "}
            <Link to="/privacy" className="text-blue-600 hover:underline">
              Privacy Policy
            </Link>
            , which explains how we collect, use, and protect your personal data.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-gray-900 mb-3">10. Changes to Terms</h2>
          <p>
            We may update or revise these Terms occasionally to reflect service or legal changes. Continued use of the
            platform after updates means you accept the revised Terms. The most current version will always be available
            on this page.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-gray-900 mb-3">11. Contact Us</h2>
          <p>
            For questions or concerns regarding these Terms, please contact us at:
          </p>
          <p className="mt-2">
            📧{" "}
            <a
              href="mailto:support@ecconnect.example"
              className="text-blue-600 hover:underline"
            >
              support@ecconnect.example
            </a>
          </p>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-gray-200 text-gray-600 text-sm py-6 px-6 md:px-20 flex justify-between flex-wrap gap-2">
        <Link to="/" className="hover:text-blue-600 hover:underline">
          ← Back to Home
        </Link>
        <span>© {new Date().getFullYear()} E&C Connect. All rights reserved.</span>
      </footer>
    </div>
  );
}
