import React from "react";
import { Link } from "react-router-dom";

export default function Contact() {
  return (
    <div className="min-h-screen bg-white text-gray-800">
      {/* Header */}
      <header className="border-b border-gray-200 py-12 px-6 md:px-20">
        <h1 className="text-4xl font-bold text-gray-900 mb-2">Contact Us</h1>
        <p className="text-sm text-gray-500">We’d love to hear from you</p>
      </header>

      {/* Main */}
      <main className="px-6 md:px-20 py-16 max-w-4xl">
        <section className="space-y-8 text-gray-700 leading-relaxed">
          <p className="text-lg">
            Have a question, feedback, or partnership idea?  
            Reach out to the <span className="font-semibold text-gray-900">E&C Connect</span> team — we’ll get back to you as soon as possible.
          </p>

          <p>
            Whether you’re a student looking to join a club, an organizer hosting an event, or a developer
            exploring integrations, we’re always open to hearing your ideas. Our goal is to make it easier
            for students and communities to connect, collaborate, and innovate.
          </p>

          <div>
            <h2 className="text-2xl font-semibold mb-3 text-gray-900">Email</h2>
            <p>
              📧{" "}
              <a
                href="mailto:support@ecconnect.example"
                className="text-blue-600 hover:underline"
              >
                support@ecconnect.example
              </a>
            </p>
          </div>

          <div>
            <h2 className="text-2xl font-semibold mb-3 text-gray-900">Office</h2>
            <p>
              E&C Connect Headquarters  
              <br />
              123 Innovation Lane  
              <br />
              Bengaluru, Karnataka 560001  
              <br />
              India
            </p>
          </div>

          <div>
            <h2 className="text-2xl font-semibold mb-3 text-gray-900">Follow Us</h2>
            <p>
              Stay connected with us on social platforms for the latest club updates, feature releases,
              and events happening near you.
            </p>
            <div className="flex space-x-5 mt-3">
              <a
                href="https://www.instagram.com"
                target="_blank"
                rel="noreferrer"
                className="text-gray-700 hover:text-blue-600 font-medium"
              >
                Instagram
              </a>
              <a
                href="https://www.linkedin.com"
                target="_blank"
                rel="noreferrer"
                className="text-gray-700 hover:text-blue-600 font-medium"
              >
                LinkedIn
              </a>
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noreferrer"
                className="text-gray-700 hover:text-blue-600 font-medium"
              >
                X (Twitter)
              </a>
            </div>
          </div>

          <p>
            Thank you for being part of the{" "}
            <span className="font-semibold text-gray-900">E&C Connect</span> community.  
            Together, we’re building a stronger, more connected network of learners, creators, and innovators.
          </p>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-gray-200 text-gray-600 text-sm py-6 px-6 md:px-20 flex justify-between flex-wrap gap-2">
        <Link to="/" className="hover:text-blue-600 hover:underline">
          ← Back to Home
        </Link>
        <span>© {new Date().getFullYear()} E&C Connect. All rights reserved.</span>
      </footer>
    </div>
  );
}
