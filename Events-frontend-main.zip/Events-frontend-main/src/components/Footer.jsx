import React from "react";
import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <footer className="mt-12 bg-gray-900 text-gray-200 border-t border-gray-800">
      <div className="max-w-7xl mx-auto px-6 py-8 md:py-10">
        <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-6">
          <div className="flex-1">
            <h3 className="text-xl font-bold text-purple-300">E&C Connect</h3>
            <p className="text-sm text-gray-400 mt-2 max-w-sm">
              Centralized hub for Events & Community Clubs — discover, join and
              organize with others.
            </p>
            <p className="text-xs text-gray-500 mt-4">
              © {new Date().getFullYear()} E&C Connect. All rights reserved.
            </p>
          </div>

          <div className="flex gap-8">
            <div>
              <h4 className="text-sm font-semibold text-gray-200 mb-3">Explore</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link
                    to="/"
                    className="text-gray-300 hover:text-purple-300"
                  >
                    Home
                  </Link>
                </li>
                <li>
                  <Link
                    to="/find-events"
                    className="text-gray-300 hover:text-purple-300"
                  >
                    Find Events
                  </Link>
                </li>
                <li>
                  <Link
                    to="/clubs"
                    className="text-gray-300 hover:text-purple-300"
                  >
                    Find Clubs
                  </Link>
                </li>
              </ul>
            </div>

           

            <div>
              <h4 className="text-sm font-semibold text-gray-200 mb-3">Legal</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link
                    to="/privacy"
                    className="text-gray-300 hover:text-purple-300"
                  >
                    Privacy
                  </Link>
                </li>
                <li>
                  <Link
                    to="/terms"
                    className="text-gray-300 hover:text-purple-300"
                  >
                    Terms
                  </Link>
                </li>
                <li>
                <Link
                    to="/contact"
                    className="text-gray-300 hover:text-purple-300"
                  >
                    Contct
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="mt-8 border-t border-gray-800 pt-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs text-gray-500">Built with ♥ • Version 1.0</p>
          <div className="flex gap-3">
            <a
              className="text-gray-300 hover:text-purple-300 text-sm"
              href="https://twitter.com/"
              target="_blank"
              rel="noreferrer"
            >
              Twitter
            </a>
            <a
              className="text-gray-300 hover:text-purple-300 text-sm"
              href="https://github.com/"
              target="_blank"
              rel="noreferrer"
            >
              GitHub
            </a>
            <a
              className="text-gray-300 hover:text-purple-300 text-sm"
              href="https://linkedin.com/"
              target="_blank"
              rel="noreferrer"
            >
              LinkedIn
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}