// src/App.jsx
import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import Homepage from "./pages/Homepage.jsx";
import FindEventsPage from "./pages/FindEvents.jsx";
import IndividualEvent from "./pages/IndividualEvent.jsx";
import JoinEvent from "./pages/JoinEvent.jsx";
import Footer from "./components/Footer.jsx";
import FindClubs from "./pages/FindClubs.jsx";
import ChatClub from "./pages/ChatClub.jsx";
import Privacy from "./pages/Privacy.jsx";
import Terms from "./pages/Terms.jsx";
import Contact from "./pages/Contact.jsx";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Homepage />} />
        <Route path="/find-events" element={<FindEventsPage />} />
        <Route path="/events/:id" element={<IndividualEvent />} />
        <Route path="/events/:id/join" element={<JoinEvent />} />
        <Route path="/clubs" element={<FindClubs />} />
        <Route path="/clubs/:id/chat" element={<ChatClub />} />
        <Route path="/privacy" element={<Privacy />} />
            <Route path="/terms" element={<Terms />} />
<Route path="/contact" element={<Contact />} />
        <Route path="/FindEvents" element={<Navigate to="/find-events" replace />} />
      </Routes>

      <Footer />
    </Router>
  );
}

export default App;
