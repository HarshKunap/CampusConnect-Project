// Utilities to call backend APIs (events & clubs)

const API_BASE =
  (typeof process !== "undefined" && process.env && process.env.REACT_APP_API_URL) ||
  (typeof window !== "undefined" && window.REACT_APP_API_URL) ||
  "https://events-backend-plum.vercel.app"; // fallback to your deployed backend

function buildUrl(path, params) {
  if (!params) return `${API_BASE}${path}`;
  const qs = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== "") qs.append(k, v);
  });
  return `${API_BASE}${path}?${qs.toString()}`;
}

async function handleRes(res) {
  const text = await res.text().catch(() => "");
  const body = text ? JSON.parse(text) : {};
  if (!res.ok) {
    const msg = body.message || body.error || body.msg || `Request failed (${res.status})`;
    const err = new Error(msg);
    err.status = res.status;
    err.body = body;
    throw err;
  }
  return body;
}

// EVENTS
export async function fetchEvents(params) {
  const url = buildUrl("/api/events", params);
  const res = await fetch(url);
  return handleRes(res);
}

export async function fetchEventById(id) {
  const res = await fetch(`${API_BASE}/api/events/${id}`);
  return handleRes(res);
}

/**
 * joinEvent
 * payload: { name, email, mobile, age, screenshotFile (optional File) }
 */
export async function joinEvent(id, payload = {}) {
  const form = new FormData();
  if (payload.name) form.append("name", payload.name);
  if (payload.email) form.append("email", payload.email);
  if (payload.mobile) form.append("mobile", payload.mobile);
  if (payload.age !== undefined) form.append("age", String(payload.age));
  if (payload.screenshotFile) form.append("screenshot", payload.screenshotFile);

  const res = await fetch(`${API_BASE}/api/events/${id}/join`, {
    method: "POST",
    body: form,
  });
  return handleRes(res);
}

// CLUBS
export async function fetchClubs(params) {
  const url = buildUrl("/api/clubs", params);
  const res = await fetch(url);
  return handleRes(res);
}

/**
 * joinClub
 * simple POST - adjust body if backend expects auth or other fields
 */
export async function joinClub(clubId, opts = {}) {
  const res = await fetch(`${API_BASE}/api/clubs/${clubId}/join`, {
    method: "POST",
    headers: opts.headers || { "Content-Type": "application/json" },
    body: opts.body ? JSON.stringify(opts.body) : JSON.stringify({}),
  });
  return handleRes(res);
}

export default {
  API_BASE,
  fetchEvents,
  fetchEventById,
  joinEvent,
  fetchClubs,
  joinClub,
};